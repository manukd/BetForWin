//
//  Match.swift
//  BetForWin
//
//  Created by Emmanuel Derepas on 06/01/2020.
//  Copyright © 2020 Emmanuel Derepas. All rights reserved.
//

import Foundation
import UIKit

class Match {
    var team1: String
    var team2: String
    var scoreT1: String
    var scoreT2: String
    
    init(team1: String, team2: String, scoreT1: String, scoreT2: String) {
        self.team1 = team1
        self.team2 = team2
        self.scoreT1 = scoreT1
        self.scoreT2 = scoreT2
    }
}
