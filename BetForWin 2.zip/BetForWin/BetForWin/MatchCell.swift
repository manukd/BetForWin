//
//  CellTableViewCell.swift
//  BetForWin
//
//  Created by Emmanuel Derepas on 06/01/2020.
//  Copyright © 2020 Emmanuel Derepas. All rights reserved.
//

import UIKit

class MatchCell: UITableViewCell {
    
    @IBOutlet weak var team1: UILabel!
    @IBOutlet weak var team2: UILabel!
    @IBOutlet weak var scoreT1: UILabel!
    @IBOutlet weak var scoreT2: UILabel!
    
    func setMatch(match: Match) {
        team1.text = match.team1
        team2.text = match.team2
        scoreT1.text = match.scoreT1
        scoreT2.text = match.scoreT2
    }

}
