//
//  ViewController.swift
//  BetForWin
//
//  Created by Emmanuel Derepas on 06/01/2020.
//  Copyright © 2020 Emmanuel Derepas. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {

    var Matchs: [Match] = []
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Matchs = initArray()
    }

    func initArray() -> [Match] {
        let headers = [
            "x-rapidapi-host": "https://api.football-data.org/v2/",
            "X-Auth-Token": "ca272f4383e94374906b8d9a99d6a2c2"
        ]

        let request = NSMutableURLRequest(url: NSURL(string: "https://api.football-data.org/v2/competitions/2015")! as URL,
                                                cachePolicy: .useProtocolCachePolicy,
                                            timeoutInterval: 10.0)
        
        request.httpMethod = "GET"
        request.allHTTPHeaderFields = headers

        var currentDayMatch = 0
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if (error != nil) {
                print(error)
            } else {
                let httpResponse = response as? HTTPURLResponse
                print(httpResponse)
                guard let content = data else {
                    print("No data")
                    return
                }
                if let json = (try? JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers)) as? [String: Any] {
                    if let currentSeason = json["currentSeason"] as? Dictionary<String, Any> {
                        if let matchday = currentSeason["currentMatchday"] as? Int {
                            currentDayMatch = matchday
                        }
                    }
                }
                else {
                    print("Not containing JSON")
                    return
                }
            }
        })
        
        dataTask.resume()
        
        let request1 = NSMutableURLRequest(url: NSURL(string: "https://api.football-data.org/v2/competitions/2015/matches?matchday=" + String(currentDayMatch))! as URL,
            cachePolicy: .useProtocolCachePolicy,
        timeoutInterval: 10.0)
        
        let dataTask1 = session.dataTask(with: request1 as URLRequest, completionHandler: { (data, response, error) -> Void in
            if (error != nil) {
                print(error)
            } else {
                let httpResponse = response as? HTTPURLResponse
                print(httpResponse)
                guard let content = data else {
                    print("No data")
                    return
                }
                if let json = (try? JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers)) as? [String: Any]
                {
                    print(json)
                    if let currentSeason = json["currentSeason"] as? Dictionary<String, Any> {
                        if let matchday = currentSeason["currentMatchday"] as? Int {
                            currentDayMatch = matchday
                        }
                    }
                }
                else {
                    print("Not containing JSON")
                    return
                }
            }
        })

        dataTask1.resume()
        
        
        var resArray: [Match] = []
        let match1 = Match(team1: "Equipe 1", team2: "Equipe 2", scoreT1: "0", scoreT2: "0")
        let match2 = Match(team1: "Dijon", team2: "PSG", scoreT1: "3", scoreT2: "1")
        let match3 = Match(team1: "Offenbach-sur-le-Main", team2: "Recklinghausen", scoreT1: "2", scoreT2: "1")
        resArray.append(match1)
        resArray.append(match2)
        resArray.append(match3)
        return resArray
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Matchs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let match = Matchs[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "matchCell") as! MatchCell
        cell.setMatch(match: match)
        return cell
    }
    
    
}
